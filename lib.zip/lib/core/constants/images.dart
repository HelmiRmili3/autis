class Images {
  static const String splashImage = 'assets/images/splash_image.png';
  static const String homeBackground = 'assets/images/homebg.jpg';
}
