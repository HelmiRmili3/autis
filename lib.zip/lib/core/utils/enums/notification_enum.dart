enum NotificationType {
  error, // Red - for critical errors
  warning, // Yellow - for warnings
  success, // Green - for success messages
}
