class CreatePatientParams {}
