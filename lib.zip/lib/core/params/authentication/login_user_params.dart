class Loginuserprams {
  String email;
  String password;

  Loginuserprams({
    required this.email,
    required this.password,
  });
}
