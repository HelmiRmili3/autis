class UserRegisterEntity {}
